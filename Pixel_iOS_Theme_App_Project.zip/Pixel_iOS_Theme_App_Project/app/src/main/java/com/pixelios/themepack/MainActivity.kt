package com.pixelios.themepack

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val bg = Color.rgb(9, 13, 37)
    private val panel = Color.rgb(27, 29, 69)
    private val purple = Color.rgb(124, 58, 237)
    private val white = Color.WHITE
    private val muted = Color.rgb(218, 218, 238)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.decorView.setBackgroundColor(bg)

        val scroll = ScrollView(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(18), dp(20), dp(28))
            setBackgroundColor(bg)
        }
        scroll.addView(root)

        root.addView(text("PIXEL iOS THEME", 27f, white, true))
        root.addView(text("An iOS-inspired look for your Google Pixel", 15f, muted, false).apply {
            setPadding(0, dp(5), 0, dp(16))
        })

        val preview = ImageView(this).apply {
            setImageResource(R.drawable.ios_wallpaper)
            scaleType = ImageView.ScaleType.CENTER_CROP
            contentDescription = "Purple and blue iOS-inspired gradient wallpaper"
            background = rounded(panel, 22)
            clipToOutline = true
        }
        root.addView(preview, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(340)))

        root.addView(text("Included features", 20f, white, true).apply { setPadding(0, dp(20), 0, dp(8)) })
        root.addView(text("• Gradient wallpaper\n• 16 iOS-inspired PNG app icons\n• Setup instructions for a Dynamic Island-style pill\n• Launcher customisation guide", 15f, muted, false).apply {
            setPadding(dp(14), dp(14), dp(14), dp(14))
            background = rounded(panel, 16)
        })

        root.addView(button("Set wallpaper") {
            try {
                startActivity(Intent(Intent.ACTION_SET_WALLPAPER))
            } catch (_: ActivityNotFoundException) {
                Toast.makeText(this, "Open the wallpaper image from Files to set it", Toast.LENGTH_LONG).show()
            }
        })
        root.addView(button("Find DynamicSpot on Google Play") {
            openUrl("https://play.google.com/store/search?q=dynamicspot&c=apps")
        })
        root.addView(button("Read setup guide") {
            showGuide()
        })

        root.addView(text("Note: Android does not allow this app to replace the Pixel system UI or create a true hardware Dynamic Island. DynamicSpot or a similar app is needed for the animated notification pill. Custom icons are applied through a compatible launcher.", 13f, muted, false).apply {
            setPadding(dp(2), dp(18), dp(2), 0)
        })
        setContentView(scroll)
    }

    private fun text(value: String, size: Float, color: Int, bold: Boolean): TextView = TextView(this).apply {
        text = value
        textSize = size
        setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
        gravity = Gravity.START
    }

    private fun button(label: String, action: () -> Unit): Button = Button(this).apply {
        text = label
        isAllCaps = false
        setTextColor(white)
        background = rounded(purple, 16)
        setPadding(dp(12), dp(10), dp(12), dp(10))
        setOnClickListener { action() }
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.topMargin = dp(12)
        layoutParams = lp
    }

    private fun showGuide() {
        val message = "1. Set the included wallpaper.\n\n2. Install a launcher that supports custom icons.\n\n3. Long-press an app icon, choose Edit, and select a PNG from the extracted theme pack's Icons_PNG folder.\n\n4. Install DynamicSpot from Google Play and configure its pill appearance. Review permissions before enabling them.\n\n5. The PNG icon files are also included in the project ZIP under app/src/main/assets/Icons_PNG."
        android.app.AlertDialog.Builder(this)
            .setTitle("Quick setup")
            .setMessage(message)
            .setPositiveButton("OK", null)
            .show()
    }

    private fun openUrl(url: String) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (_: ActivityNotFoundException) {
            Toast.makeText(this, "No browser or Play Store app found", Toast.LENGTH_LONG).show()
        }
    }

    private fun rounded(color: Int, radiusDp: Int): android.graphics.drawable.GradientDrawable =
        android.graphics.drawable.GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radiusDp).toFloat()
        }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
