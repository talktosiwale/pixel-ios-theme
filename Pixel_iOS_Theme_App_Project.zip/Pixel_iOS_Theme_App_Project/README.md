# Pixel iOS Theme Android app project

This is an Android Studio project for a simple companion app that previews the included wallpaper and links to a DynamicSpot search on Google Play. It includes 16 iOS-inspired PNG icons as project assets.

## Build an APK

1. Install Android Studio on a computer.
2. Open this folder (`Pixel_iOS_Theme_App_Project`) in Android Studio.
3. Allow Gradle sync and install Android SDK Platform 35 if prompted.
4. Choose **Build → Build APK(s)**.
5. The debug APK will be generated at `app/build/outputs/apk/debug/app-debug.apk`.
6. Transfer the APK to your Pixel and install it. If prompted, allow installation from that source only if you trust the file you built.

## What the app does

- Shows the included gradient wallpaper.
- Opens Android's wallpaper chooser.
- Links to DynamicSpot search on Google Play.
- Displays setup guidance.

## Important limitations

This is not a system theme and cannot change Android's status bar, system icons, or physical camera cut-out. The Dynamic Island-style animation requires a separate app. Custom icons are supplied as PNG assets and need a launcher that supports custom icons. This project has not been compiled or device-tested in this environment.
